# Building MediaScope Lower Thirds via GitHub Actions

The project already ships a full CI pipeline (`.github/workflows/`) that builds
Windows, macOS, and Linux versions automatically — you don't need to install
Qt, the OBS SDK, or any compiler yourself. You just need a GitHub repo.

## Steps

1. **Create a new GitHub repository** (private is fine) — e.g. `mediascope-lower-thirds`.
   Don't initialize it with a README (you already have one).

2. **Unzip `mediascope-lower-thirds-source.zip`** and push it as the initial commit:

   ```bash
   cd mediascope-lower-thirds
   git init
   git add .
   git commit -m "Initial MediaScope Lower Thirds build"
   git branch -M main
   git remote add origin https://github.com/<your-username>/mediascope-lower-thirds.git
   git push -u origin main
   ```

3. **Push a version tag** to trigger the release build. The workflow only builds
   release artifacts (including the Windows `.exe` installer and `.zip`) when you
   push a tag matching `X.Y.Z`:

   ```bash
   git tag 1.0.0
   git push origin 1.0.0
   ```

4. **Watch it build**: go to the "Actions" tab on your repo. The `Push` workflow
   runs `Build Project`, which compiles for Windows x64 (and macOS/Linux too,
   if you don't need those you can later trim the workflow, but it's harmless
   to leave them).

5. **Get the installer**: once the build finishes (takes ~10–20 minutes on
   GitHub's runners), go to the repo's "Releases" page. There will be a **draft
   release** named `MediaScope Lower Thirds 1.0.0` with the built files attached,
   including:
   - `mediascope-lower-thirds-*-windows-x64-*.zip` (the plugin files)
   - `mediascope-lower-thirds-*-windows-x64-*.exe` (the installer)

   Publish the draft release (or just download the assets directly from the
   draft) and run the `.exe` on your Windows machine with OBS installed.

## If a future change is needed

Any time you want to tweak a template, color, or behavior, ask me to edit the
source, then just repeat step 3 with a new tag (e.g. `1.0.1`) — GitHub Actions
rebuilds automatically. No local Windows/Qt toolchain required at any point.

## What's already been reworked in this build

- Fully rebranded from "VinciFlow" to "MediaScope Lower Thirds" — no leftover
  references anywhere in code, docs, or installer strings.
- Every outbound link removed: no Ko-fi, Discord, X, Facebook, Mastodon,
  Instagram, YouTube, or "streamrsc.com" redirects anywhere. The dead remote
  marketplace/API code (which was already non-functional upstream) has been
  disabled and its UI hidden.
- 8 built-in lower-third styles, each with a distinct layout and its own
  entrance/exit animation: Classic Card, Minimal Bar, Glass Panel, News
  Ribbon, Gradient Wave, Neon Outline, Corner Tag, Split Duo. Pick one from
  the "+" button in the dock — it now opens a style picker instead of always
  adding the same design.
- Logo/profile photo support carries through every template (drag a PNG/JPG
  in per lower third).
- Font picker already lists every font installed on your system; each
  built-in style also suggests a distinct font (Oswald, Manrope, Bebas Neue,
  Sora, JetBrains Mono, Poppins, Space Grotesk, Inter) so the 8 styles feel
  visually distinct out of the box.
- Everything remains fully editable afterward via the existing template
  editor (HTML/CSS/JS per lower third), so you can tweak colors, sizes, or
  layout further without needing to touch C++ at all.
